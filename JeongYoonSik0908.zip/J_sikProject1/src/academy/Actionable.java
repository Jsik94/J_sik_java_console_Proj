package academy;

public interface Actionable extends DisplayInterface{

    int run();
}
