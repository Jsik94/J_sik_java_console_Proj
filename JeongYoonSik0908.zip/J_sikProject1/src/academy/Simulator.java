package academy;

public class Simulator {


    public static void main(String[] args) {

        Academy test ;

        test = new Academy(222);
        test.run();
    }


}
