package academy;

public interface DisplayInterface {

//    public void show(int menu_cnt, String[] menus);

    public void show();
}
